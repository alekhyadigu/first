package p;
import java.util.*;

import org.hibernate.cfg.Configuration;
import org.hibernate.SessionFactory;
import org.hibernate.*;
import org.hibernate.Transaction;



public class EmpHiber {

	public static void main(String ar[])
	{
		Configuration cfg=new Configuration();
		cfg.configure("hiber.cfg.xml");
		SessionFactory sf=cfg.buildSessionFactory();
		
		Session ses=sf.openSession();
		Transaction ts=ses.beginTransaction();
		ts.begin();
		
	/*Query q=ses.createQuery("update Emp set ename=:n where id=:i");
	q.setParameter("n","yy");
	q.setParameter("i","101");
	int z=q.executeUpdate();
	System.out.println("z="+z);
	ts.commit();*/
		
		String s="e9";
		Query query=ses.createQuery("delete from Emp where id='102'");
		 int z=query.executeUpdate();
		 System.out.println("z="+z);
		 ts.commit();
	}

	}

