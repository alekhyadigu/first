package p;

public class ConEmp extends Emp {
	String pay,period;
	public ConEmp() {}
	 
	    public String getPay()
	    {
	    	return pay;
	    }

   
    public void setPay(String pay)
    {
    	this.pay=pay;
    }
    public String getPeriod()
    {
    	return period;
    }


public void setPeriod(String period)
{
	this.period=period;
}
   
}
