package p;
import java.util.*;

import org.hibernate.cfg.Configuration;
import org.hibernate.SessionFactory;
import org.hibernate.*;
import org.hibernate.Transaction;



public class EmpHiber {

	public static void main(String ar[])
	{
		Configuration cfg=new Configuration();
		cfg.configure("hiber.cfg.xml");
		SessionFactory sf=cfg.buildSessionFactory();
		
		Session ses=sf.openSession();
		Transaction ts=ses.beginTransaction();
		ts.begin();
		
		/*Emp e1=new Emp();
		e1.setId("102");
		e1.setEcode("aaabh");
		e1.setEname("pph");
		String eid=(String)ses.save(e1);
		ts.commit();
		System.out.print("eid= "+eid);*/
		
		/*List e1=ses.createQuery("from Emp").list();
		Iterator itr=e1.iterator();
		while(itr.hasNext()) {Emp em=(Emp)itr.next();
		System.out.println("eid="+em.getId());
		System.out.println("ecode="+em.getEcode());}
		ts.commit();*/
		
		/*Emp em=(Emp)ses.get(Emp.class, "101");
		em.setEname("alekhya");
		ses.update(em);
		ts.commit();*/
		
		Object o=ses.load(Emp.class, new String("4444"));
		Emp e=(Emp)o;
		ses.delete(e);
		ts.commit();
		System.out.println("deleted sucessfully");
		}

	}

