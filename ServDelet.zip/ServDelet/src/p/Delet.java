package p;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Delet extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Connection conn=null;
		String url="jdbc:mysql://localhost:3306/";
		String dbName= "db1";
		String driver="com.mysql.jdbc.Driver";
		String userName="root";
		String password="root";
		PrintWriter out= response.getWriter();
		String s=request.getParameter("ecode");
		//String s1=request.getParameter("ename");
        out.print("s="+s);
        //out.print("s1"+s1);
        out.print("<br><br>");
        
        
        try
        {
        	Class.forName(driver);
        	conn=DriverManager.getConnection(url+dbName,userName,password);
        	PreparedStatement ps=conn.prepareStatement("delete from emp where ecode=?");
        	ps.setString(1, s);
        	


        	int x=ps.executeUpdate();
        	conn.close();
 
        }
        	catch(Exception e)
        {
        		e.printStackTrace();
      
        			
        		
        	
        }
        
        
	}
}
	

