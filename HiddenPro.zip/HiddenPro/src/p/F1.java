package p;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.*;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class F1 extends HttpServlet {
    private static final long serialVersionUID = 1L;
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try
        {
            PrintWriter out=response.getWriter();
            String s=request.getParameter("uname");
            String s1=request.getParameter("pword");
            s=s.trim();
            s1=s1.trim();
            String s2="Alekhya";
            String s3="D";
            if(s.equals("abc")&&s1.equals("abcd"))
            {
                out.print("VALID USER");
                out.println("click");
                out.println("<a href='/HiddenPro/2?pp="+s+"&&p2="+s1+"'>here</a>");
            }
            else
            {
                out.println("INVALID USER");
               
            }
           
        }
        catch(Exception e) {}
       
    }
}