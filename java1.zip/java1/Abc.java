class D{
	int x;//int y;//int s;
	void show(){
		//s=x+y;
		//System.out.println("sum="+s);
		System.out.println("show()");
	}
}



class Abc
{
	
public static void main(String ar[])

{
	D d1=new D();
	d1.show();
	d1.x=Integer.parseInt(ar[0]);
	//d1.y=Integer.parseInt(ar[1]);
	//int c= d1.x+d1.y;
	
//System.out.println("u in main="+u);

}
}