class A
{
public static void main(String ar[])
{
System.out.println("hello");
}
}