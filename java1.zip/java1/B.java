
class B
{
	
public static void main(String ar[])

{
int x[][]=new int[2][2];
int y[][]=new int[2][2];
int z[][]=new int[2][2];
x[0][0]=1;
x[0][1]=2;
x[1][0]=3;
x[1][1]=4;
y[0][0]=1;
y[0][1]=2;
y[1][0]=3;
y[1][1]=4;
for(int i=0;i<2;i++){
	for(int j=0;j<2;j++){
		z[i][j]=x[i][j]+y[i][j];
		System.out.println(z[i][j]);
	}
}

}
}