package p;

public class Address {
	String city,aid;
	public Address() {}
	 public String getAid()
	    {
	    	return aid;
	    }
	 public void setAid(String aid)
	    {
	    	this.aid=aid;
	    }
	   
    
    public String getCity()
    {
    	return city;
    }


public void setCity(String city)
{
	this.city=city;
}
   
}
