package p;
import java.util.*;

import org.hibernate.cfg.Configuration;
import org.hibernate.SessionFactory;
import org.hibernate.*;
import org.hibernate.Transaction;



public class EmpHiber {

	public static void main(String ar[])
	{
		Configuration cfg=new Configuration();
		cfg.configure("hiber.cfg.xml");
		SessionFactory sf=cfg.buildSessionFactory();
		
		Session ses=sf.openSession();
		Transaction ts=ses.beginTransaction();
		ts.begin();
		
	RegEmp re=new RegEmp();
	re.setId("7");
	re.setEname("aaa");
	re.setBonus("800");
	re.setSal("40000");
	ses.persist(re);
	ses.flush();
	ses.clear();
	
	ConEmp ce=new ConEmp();
	ce.setId("17");
	ce.setEname("aaa");
	ce.setPay("8000");
	ce.setPeriod("4");
	ses.save(ce);
	ts.commit();
	ses.clear();
	
	
	
	
	}

	}

