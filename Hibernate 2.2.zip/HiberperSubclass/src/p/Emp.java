package p;

public class Emp {
	String ename,id;
	public Emp() {}
	 public String getId()
	    {
	    	return id;
	    }
	 public void setId(String id)
	    {
	    	this.id=id;
	    }
	   
    
    public String getEname()
    {
    	return ename;
    }


public void setEname(String ename)
{
	this.ename=ename;
}
   
}
