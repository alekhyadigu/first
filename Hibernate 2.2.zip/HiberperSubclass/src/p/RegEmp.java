package p;

public class RegEmp extends Emp {
	String sal,bonus;
	public RegEmp() {}
	 
	    public String getSal()
	    {
	    	return sal;
	    }

   
    public void setSal(String sal)
    {
    	this.sal=sal;
    }
    public String getBonus()
    {
    	return bonus;
    }


public void setBonus(String bonus)
{
	this.bonus=bonus;
}
   
}
