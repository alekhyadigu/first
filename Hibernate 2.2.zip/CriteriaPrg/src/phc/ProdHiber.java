package phc;


import java.util.Iterator;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.classic.Session;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Restrictions;


public class ProdHiber {
	public static void main(String[] args)
	{
		Configuration cfg=new Configuration();
		cfg.configure("hibernate.cfg.xml");
		SessionFactory sf=cfg.buildSessionFactory();
		
		Session sess=sf.openSession();
		
		Criteria crit = sess.createCriteria(Prod1.class);
		
		Criterion cn = Restrictions.gt("price", Double.valueOf(17000));
		
		crit.add(cn);
		List l =crit.list();
		System.out.println("List total size...."+l.size());
		Iterator itr = l.iterator();
		
		while(itr.hasNext())
		{
			Prod1 p = (Prod1)itr.next();
			System.out.println(" "+p.getPid());
			System.out.println(" "+p.getPname());
			System.out.println(" "+p.getPrice());
			System.out.println(" --------- ");
		}
		sess.close();
		sf.close();
	}
}