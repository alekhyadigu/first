class Str {
	public static void main(String args[])
	{
		String s1="Hello";
		String s2 = "Hello";
		String s = new String("Hello");
		if(s==s1)
			System.out.println("s == s1");
		else
			System.out.println("s != s1");
		if(s1==s2)
			System.out.println("s1 == s2");
		else
			System.out.println("s != s2");
		if(s.equals(s2))
			System.out.println("s.equals(s2)");
		else
			System.out.println("s not equals(s2)");
		if(s1.equals(s2))
			System.out.println("s1.equals(s2)");
		else
			System.out.println("s1 not equals(s2)");
	}
}
