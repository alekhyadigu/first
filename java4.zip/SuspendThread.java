class Demoo extends Thread{
	Demoo()
	{
		start();
	}
	
	public void run()
	{
		System.out.println("Hello");
		try
		{
			sleep(1000);
		}
		catch(InterruptedException ie)
		{
			System.out.println("Exception");
		}
		System.out.println("Bye");
	}
}
public class SuspendThread {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Demoo d = new Demoo();
		Demoo d1 = new Demoo();

	}

}
