class Demo implements Runnable {
	int i;
	String n;
	public void run()
	{
		for(i=0;i<5;i++)
		{
		System.out.println("Child Thread "+n+" i = "+i);
		System.out.println("Child Thread "+n+" finished");
		}
	}
}
public class DemoThread {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Demo d = new Demo();
		Demo d1 = new Demo();
		Thread t = new Thread(d);
		Thread t1 = new Thread(d);
		t.start();
		t1.start();

	}

}
