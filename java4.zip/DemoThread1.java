class Demo1 extends Thread{
	int i;
	String n;
	Demo1()
	{
		start();
	}
	public void run()
	{
		for(i=0;i<5;i++)
		{
		System.out.println("Child Thread "+n+" i = "+i);
		System.out.println("Child Thread "+n+" finished");
		}
	}
}
public class DemoThread1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Demo1 d = new Demo1();
		Demo1 d1 = new Demo1();

	}

}
