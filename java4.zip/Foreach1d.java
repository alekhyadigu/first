class foreach {
	public static void main(String args[])
	{
		int x[] = {1,2,3,4} ;
		for(int i : x)
		{
			System.out.println(i);
		}
		
	}
}
