impor java.io.*;

class FIS

{
     static int i;
	 static FileInputStream f;
	 public static void main(String ar[]) throws IOException
	 {
	   try
	   {
	      f=new FileInputStream("fine.txt");
	   }
	   catch(FlieNotFoundException e)
	   {
	      Sytem.out.println("error");
	   }
	   do 
	   {
	         i=f.read();
			 if(i!=-1)
			       System.out.println((char)i);
	   }while(i!=-1);
	 }
}