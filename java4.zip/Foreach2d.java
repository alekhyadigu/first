class foreach {
	public static void main(String args[])
	{
		int y[][] = {{5,6,7,8},{1,2,3,4},{1,4,7,10}};
		
		for(int j[] : y)
		{
			for(int k : j)
			{
			System.out.println(k);
			}
		}
	}
}
