impor java.io.*;

class UserIn

{
    
	 public static void main(String ar[]) throws IOException
	 {
	   int i;
	   BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
	   System.out.println("enter your name:");
	   System.out.println("name="+br.readLine());
	   }
}