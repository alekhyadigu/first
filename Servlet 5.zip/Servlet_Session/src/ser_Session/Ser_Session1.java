package ser_Session;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Date;

import javax.servlet.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class Ser_Session1 extends HttpServlet {

	protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		PrintWriter out=res.getWriter();
		String s=req.getParameter("uname");
		String s1=req.getParameter("pword");
		HttpSession ses=req.getSession(true);
		if(s.equals("abc")&&s1.equals("abc"))
		{
			out.println("Welcome "+s);
			ses.setAttribute("user", s);
			out.println("<br>login page ID : "+ ses.getId());		
			out.println("<br>Creation ID :"+ses.getCreationTime());
			out.println("<br>Last Access Time :"+new Date(ses.getLastAccessedTime()));
			out.println("<br>Max Inactive time :"+ses.getMaxInactiveInterval());
			out.println("<br><a href='/Servlet_Session/2'>visit</a>");
		}
		else
		{
			RequestDispatcher rd=req.getRequestDispatcher("index.html");
			out.println("<font color=red>Either user name or password is wrong</font>");
			rd.include(req, res);
		}
	}


}
