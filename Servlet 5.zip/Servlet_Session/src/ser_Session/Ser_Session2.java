package ser_Session;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class Ser_Session2 extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		HttpSession Session= request.getSession(false);
		String n=(String)Session.getAttribute("user");
		out.println("<br>Hello "+n);
		out.println("<br>Logout Page ID: "+Session.getId());
		Session.invalidate();
		
	}

}
