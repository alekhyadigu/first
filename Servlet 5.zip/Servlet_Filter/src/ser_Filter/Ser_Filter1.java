package ser_Filter;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Ser_Filter1 extends HttpServlet {
	protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
	
		try {
			PrintWriter out=res.getWriter();
			out.println("Hi Authentication Passed");
		}catch(Exception e) {System.out.println(e);}
	}

	
}
