package collection;

import java.util.*;


public class HashMapEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	HashMap hm = new HashMap();
	
	hm.put("pp", new Double(543.71));
	hm.put("qq", new Double(837.90));
	hm.put("asd", new Double(17.99));
	hm.put("kkk", new Double(233.8));
	hm.put("ii", new Double(543.71));
	
	Set set = hm.entrySet();
	
	Iterator i = set.iterator();
	
	while(i.hasNext())
	{
		Map.Entry me = (Map.Entry)i.next();
		System.out.println(me.getKey() + ": ");
		System.out.println(me.getValue());
	}
	System.out.println();

	}

}
