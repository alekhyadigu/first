package Collections;
import java.util.*;

public class ArrayListEg {
	
	static void arrayListEg1()
	{
		ArrayList al = new ArrayList();
		System.out.println("Initial size of al: "+al.size());
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter value");
		String s1 = sc.next();
		al.add(s1);
		System.out.println("Enter value");
		String s2 = sc.next();
		al.add(s2);
		System.out.println("Enter value");
		String s3 = sc.next();
		al.add(s3);
		System.out.println("Enter value");
		String s4 = sc.next();
		al.add(s4);
		System.out.println("Enter value");
		String s5 = sc.next();
		al.add(s5);
		System.out.println("Enter value");
		String s6 = sc.next();
		al.add(s6);
		System.out.println("Enter value");
		String s7 = sc.next();
		al.add(1,s7);
		
		System.out.println("Size of al after additions: "+al.size());
		
		System.out.println("Contents of al: "+al);
		
		al.remove(s1);
		al.remove(2);
		
		System.out.println("Size of al after deletions: "+al.size());
		System.out.println("Contents of al: "+al);
		
		Iterator itr = al.iterator();
		while(itr.hasNext())
		{
			System.out.println(itr.next());
		}
		
		
		
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		arrayListEg1();
		
		
		

	}

}
