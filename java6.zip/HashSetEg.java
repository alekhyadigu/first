package Collections;
import java.util.*;

public class HashSetEg {
	
	static void hashSetEg()
	{
		HashSet hs = new HashSet();
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter value");
		String s1 = sc.next();
		hs.add(s1);
		System.out.println("Enter value");
		String s2 = sc.next();
		hs.add(s2);
		System.out.println("Enter value");
		String s3 = sc.next();
		hs.add(s3);
		System.out.println("Enter value");
		String s4 = sc.next();
		hs.add(s4);
		System.out.println("Enter value");
		String s5 = sc.next();
		hs.add(s5);
		System.out.println("Enter value");
		String s6 = sc.next();
		hs.add(s6);
		
		System.out.println(hs);
		System.out.println("With iterator");
		
		Iterator itr = hs.iterator();
		
		while(itr.hasNext())
		{
			System.out.println(itr.next());
		}
		
		
	}
	
	public static void main(String args[]) 
	{
		
		hashSetEg();
	}

}
