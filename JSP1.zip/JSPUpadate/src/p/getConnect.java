package p;
import java.sql.*;
public class getConnect {
	public	static Connection connect(){
			System.out.println("My Sql Connection");
			Connection conn=null;
			String url="jdbc:mysql://localhost:3306/";
			String dbName="db4";
			String driver="com.mysql.jdbc.Driver";
			String userName="root";
			String password="root";
			try{
				Class.forName(driver);
				conn=DriverManager.getConnection(url+dbName,userName,password);
				System.out.println("My Sql Connection established");
				}
			catch(Exception e) {
				e.printStackTrace();
			}
			return conn;
			
					}

}
