package p;
import java.util.*;

import org.hibernate.cfg.Configuration;
import org.hibernate.SessionFactory;
import org.hibernate.*;
import org.hibernate.Transaction;



public class EmpHiber {

	public static void main(String ar[])
	{
		Configuration cfg=new Configuration();
		cfg.configure("hiber.cfg.xml");
		SessionFactory sf=cfg.buildSessionFactory();
		
		Session ses=sf.openSession();
		Transaction ts=ses.beginTransaction();
		ts.begin();
		
		Emp e1=new Emp();
		e1.setId("4444");
		e1.setEcode("aaabh");
		e1.setEname("pp");
		ses.persist(e1);
		System.out.print("sucess");
		ts.commit();
	}
}
