package ck1;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Ck1 extends HttpServlet {
	protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		PrintWriter out=res.getWriter();
		String s=req.getParameter("uname");
		String s1=req.getParameter("pword");
		Cookie cr=new Cookie("user",s);
		Cookie cr1=new Cookie("user",s1);
		res.addCookie(cr);
		res.addCookie(cr1);
		out.print("Cookie containing username is stored in your browser");
		out.print("<html><body>");
		out.print("<form method='get' action='pass1'>");
		out.print("<input type='submit' value ='Login'>");
		out.print("</html></body>");
	}


}
