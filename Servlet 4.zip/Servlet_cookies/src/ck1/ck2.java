package ck1;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Cookie;




public class ck2 extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		try
		{
		PrintWriter out = response.getWriter();
		String str = null;
		String str1 = null;
		Cookie[] cr = request.getCookies();
		if(cr!=null)
		{
			for(int i=0;i<cr.length;i++)
			{
			str = cr[i].getName();
			str1 = cr[i].getValue();
			out.println("Hello "+str+" "+str1);
			}
		}
		else
		{
			out.println("No cookie was found");
		}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}

}
