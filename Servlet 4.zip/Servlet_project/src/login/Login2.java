package login;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Login2 extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			PrintWriter out = response.getWriter();
			Cookie[] cr = request.getCookies();
			
			String str1 = null;
			if(cr!=null)
			{
				for(int i=0;i<cr.length;i++)
				{
				str1 = cr[i].getValue();
				out.println("Hello "+str1);
				}
			}
			else
			{
				out.println("No cookie was found");
			}
			String s=request.getParameter("ename");
			String s1=request.getParameter("ecode");
			String s2=request.getParameter("click");
			Connection conn = getconnect.connect();
			if(s2.equals("Update"))	
			{
				PreparedStatement ps=conn.prepareStatement("update emp set ename=? where ecode=?");
				ps.setString(1,s);
				ps.setString(2,s1);
				int x=ps.executeUpdate();
				System.out.println(x+" Record Updated");
				conn.close();
				System.out.println("Disconnected from database");
			}
			else if(s2.equals("Delete")){
				PreparedStatement ps=conn.prepareStatement("delete from emp where ecode=?");
				ps.setString(1,s);
				int x=ps.executeUpdate();
				System.out.println(x+" Record Deleted");
				conn.close();
				System.out.println("Disconnected from database");
			}
			else if(s2.equals("Insert")){
				java.sql.PreparedStatement ps=conn.prepareStatement("insert into emp values(?,?)");
				ps.setString(1,s);
				ps.setString(2,s1);
				int x=ps.executeUpdate();
				System.out.println(x+" Record Inserted");
				conn.close();
				System.out.println("Disconnected from database");
			}
			else if(s2.equals("Display")){
				Statement sm=conn.createStatement();
				ResultSet rs=sm.executeQuery("select * from emp");
				out.println("<table border =1 bgcolour=lightblue>");
				out.println("<th>ECODE</th><th>ENAME</th>");
				while(rs.next())
				{
					String f=rs.getString(1);
					String f1=rs.getString(2);
					out.println("<tr><td>"+f+"</td><td>"+f1+"</td></tr>");
				}
				out.println("</table>");
				conn.close();
				System.out.println("Disconnected from database");
			}
				
		}catch(Exception e) {}
		}
}
