package login;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class Login1 extends HttpServlet {
	protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		try {
				Connection conn = getconnect.connect();
				Statement sm=conn.createStatement();
				ResultSet rs=sm.executeQuery("select * from login");
				PrintWriter out=res.getWriter();
				boolean check=false;
				String s=req.getParameter("uname");
				Cookie cr=new Cookie("user",s);
				res.addCookie(cr);
				String s1=req.getParameter("password");
				while(rs.next())
				{
					String f=rs.getString(1);
					String f1=rs.getString(2);
					System.out.println("Valid User "+s);
					if(s.equals(f)&&s1.equals(f1))
					{   System.out.println("Valid User "+s);
						out.print("Valid User "+s);
						out.print("<html><body>");
						out.print("<form method='get' action='pass1'>");
						out.print("ECODE:<input type='text' name='ecode'>");
						out.print("<br><br>");
						out.print("ENAME:<input type='text' name='ename'>");
						out.print("<br><br>");
						out.print("<input type='submit' value ='Update' name='click'>");
						out.print("<input type='submit' value ='Delete' name='click'>");
						out.print("<input type='submit' value ='Insert' name='click'>");
						out.print("<input type='submit' value ='Display' name='click'>");
						out.print("</html></body>");
						check=true;
						break;
					}
					
				}
				if(!check)
				out.print("Invalid User");
			
		}catch(Exception e) {}
	}

}
