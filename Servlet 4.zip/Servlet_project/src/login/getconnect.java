package login;

import java.sql.Connection;
import java.sql.DriverManager;
class getconnect {
	
			static Connection connect(){
				System.out.println("My Sql Connection");
				Connection conn=null;
				String url="jdbc:mysql://localhost:3306/";
				String dbName="db1";
				String driver="com.mysql.jdbc.Driver";
				String userName="root";
				String password="root";
				try{
					Class.forName(driver);
					conn=DriverManager.getConnection(url+dbName,userName,password);
					System.out.println("My Sql Connection established");
					}
				catch(Exception e) {
					e.printStackTrace();
				}
				return conn;
				
						}

	
}