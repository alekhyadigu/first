package p;
import java.util.*;

import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.cfg.Configuration;
import org.hibernate.SessionFactory;
import org.hibernate.*;
import org.hibernate.Transaction;



public class HiberAnnot {

	public static void main(String ar[])
	{
		Configuration cfg=new Configuration();
		cfg.configure("hiber.cfg.xml");
		//SessionFactory sf=cfg.buildSessionFactory();
		
		SessionFactory sf=new AnnotationConfiguration().addAnnotatedClass(EmpA.class).configure().buildSessionFactory();
		Session ses=sf.openSession();
		Transaction ts=ses.beginTransaction();
		ts.begin();
		
		EmpA e1=new EmpA();
		e1.setId("102");
		e1.setEcode("aaabh");
		e1.setEname("pph");
		//String eid=(String)ses.save(e1);
		ses.persist(e1);
		System.out.print("sucess");
		
		ts.commit();
		
		}

	}

