package p;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="EMPAnnot")

public class EmpA {
	
@Id
String id;
@Column(name="ecode")
String ecode;
@Column(name="ename")
String ename;

public EmpA() {}
public String getId() {
	return id;
}
public void setId(String id) {
	this.id=id;
}

public String getEcode() {
	return ecode;
}
public void setEcode(String ecode) {
	this.ecode=ecode;
}

public String getEname() {
	return ename;
}
public void setEname(String ename) {
	this.ename=ename;
}
}
