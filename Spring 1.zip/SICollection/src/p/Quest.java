package p;

import java.util.*;


public class Quest {

    String q;
	int id;
	List<String> ans;
	
	public int getId()
    {
    	return id;
    }
 public void setId(int id)
    {
    	this.id=id;
    }
	 
 public String getQ()
 {
 	return q;
 }
public void setQ(String q)
 {
 	this.q=q;
 }
public List<String> getAns()
{
	return ans;
}
public void setAns(List<String> ans)
{
	this.ans=ans;
}
 void dis()
 {
	System.out.println(id+" "+q+" ");
	Iterator it=ans.iterator();
	System.out.println("Courses are:");
	while(it.hasNext())
	{
		System.out.println(it.next());
	}
}
}
