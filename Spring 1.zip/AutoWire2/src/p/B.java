package p;  
public class B {  
B()
{
	System.out.println("A and b are created");
}  
void print()
{
	System.out.println("hello b");}  
} 