package p;  
public class A {  
B b;  
A()
{}

public A(B b) 
{  
    this.b = b;  
}  
void print()
{
	System.out.println("hello a");
}  
void display()
{  
    print();  
    b.print();  
}  
} 