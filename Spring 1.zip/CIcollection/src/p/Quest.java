package p;

import java.util.*;


public class Quest {

    String q;
	int id;
	List<Answers> ans;
	
	Quest(int id,String q, List<Answers> ans)
	    {
	    	this.id=id;
	    	this.q=q;
	    	this.ans=ans;
	    }
	 
 void dis()
 {
	System.out.println(id+" "+q+" ");
	Iterator it=ans.iterator();
	System.out.println("ans are:");
	while(it.hasNext())
	{
		System.out.println(it.next());
	}
}
}
