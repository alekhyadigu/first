package p;

import java.util.*;


public class Quest {

    String q;
	int id;
	List<Answers> ans;
	
	public int getId()
    {
    	return id;
    }
 public void setId(int id)
    {
    	this.id=id;
    }
	 
 public String getQ()
 {
 	return q;
 }
public void setQ(String q)
 {
 	this.q=q;
 }
public List<Answers> getAns()
{
	return ans;
}
public void setAns(List<Answers> ans)
{
	this.ans=ans;
}
 void dis()
 {
	System.out.println(id+" "+q+" ");
	Iterator it=ans.iterator();
	System.out.println("ans are:");
	while(it.hasNext())
	{
		System.out.println(it.next());
	}
}
}
