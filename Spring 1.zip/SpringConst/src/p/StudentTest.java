package p;

import org.springframework.context.ApplicationContext;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
public class StudentTest {

	
	public static void main(String ar[])
	{
		ApplicationContext context=new ClassPathXmlApplicationContext("applicationContext.xml");
		
		Student st=(Student)context.getBean("e1");
		st.show();
	}
	
}
