package p;

public class Student {
private String name;
	private int id;
	 public Student()
	    {
	    	System.out.println("def cons");
	    }
	 public Student(int id)
	    {
	    	this.id=id;
	    }
	 
public Student(String fn,int id)
{
	this.id=id;
	this.name=fn;
}
void show()
{
	System.out.println(" "+id+" "+name);
}
}