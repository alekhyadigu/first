class Scon1{
	int x;
	Scon1(int p)
	{
	x=p;
	} 
}	
	class S extends Scon1
	{
		S()
		{
			super(30);
		}
	void show()
	{
	    
		System.out.println("x="+x);
		
	}
	
public static void main (String ar[])
{
S a1=new S();
a1.show();
}
}