class Hybrid{
	int x;
	//static int p;
	void show()
	{
		System.out.println("main class");
		//System.out.println("x="+x);
	}
}	
	class S extends Hybrid
	{
	int y=10;
	void show()
	{
		System.out.println("class S");
		System.out.println("x="+x);
		super.show();
	}
	}
	class S1 extends S
	{
	void show()
	{
	//ystem.out.println("show()");
		System.out.println("x="+x);
		super.show();
	}
public static void main (String ar[]){
S1 a1=new S1();
a1.show();

class S2 extends S
	{
	void show()
	{
	//ystem.out.println("show()");
		System.out.println("y="+y);
		//super.show();
	}
public static void main (String ar[]){
S2 a2=new S2();
a2.show();
}
	}