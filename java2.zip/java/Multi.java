class Multi{
	int x;
	//static int p;
	void show()
	{
		System.out.println("main class");
		//System.out.println("x="+x);
	}
}	
	class S extends Multi
	{
	//int y=10;
	void show()
	{
		System.out.println("class S");
		System.out.println("x="+x);
		super.show();
	}
	}
	class S1 extends S
	{
	void show()
	{
	//ystem.out.println("show()");
		System.out.println("x="+x);
		super.show();
	}
public static void main (String ar[]){
S1 a1=new S1();
a1.show();

}
}