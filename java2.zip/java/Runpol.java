class Runpol{
	int x;
	void show()
	{
		//System.out.println("main class");
		//System.out.println("x="+x);
	}
}	
	class S extends Runpol
	{
	void show()
	{
		System.out.println("class S");
		System.out.println("x="+x);
	}
	}
	class S1 extends Runpol
	{
	void show()
	{
	    System.out.println("class S1");
		System.out.println("x="+x);
	}
public static void main (String ar[]){
Runpol a1=new S();
a1.show();
Runpol a2=new S1();
a2.show();

}
}