class Scon{
	int x;
	/*Scon()
	{
	x=10;
	} */
}	
	class S extends Scon
	{
	void show()
	{
	
		System.out.println("x="+x);
		
	}
	
public static void main (String ar[])
{
S a1=new S();
a1.show();
}
}