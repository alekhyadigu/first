class A{
	int x;
	static int p;
	A(int x)
	{
		this.x=x;
	}
	A()
	{
		x=20;
	}
	void show()
	{
		System.out.println("show()");
		System.out.println("x="+x);
	}
public static void main (String ar[]){
A a1=new A();
A a2=new A(30);
a1.show();
a2.show();
}
}