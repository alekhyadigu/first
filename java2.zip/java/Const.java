class Single{
	int x;
	//static int p;
}	
	class S extends Single
	{
	void show()
	{
		System.out.println("show()");
		System.out.println("x="+x);
	}
	
public static void main (String ar[]){
Single a1=new Con();

a1.show();
}
}