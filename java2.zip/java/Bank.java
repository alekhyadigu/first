import java.util.Scanner;
class Bank
{
String name_Depositor;
String Acc_No;
String TypeOfAcc;
long Balance;
Scanner person= new Scanner(System.in);

void CustDet()
{
System.out.println("Enter the Name:");
name_Depositor=person.nextLine();
System.out.println("Enter the Account number:");
Acc_No=person.nextLine();
System.out.println("Enter the Type of Account:");
TypeOfAcc=person.nextLine();
System.out.println("Enter the Balance:");
Balance=person.nextLong();
}
void CustDep()
{
long dep;
System.out.println("Enter the Amount to be deposited:");
dep=person.nextLong();
Balance=Balance+dep;
System.out.println("The remaining Balance is:"+Balance);
}
void CustWith()
{
long with;
System.out.println("Enter the Amount for withdrawal:");
with=person.nextLong();
if(Balance>=with)
{
Balance=Balance-with;
System.out.println("The remaining Balance is:"+Balance);
}
else
{
System.out.println("Insufficient Funds");
}
}

public static void main(String arg[])
{

Bank B =new Bank();
B.CustDet();
B.CustDep();
B.CustWith();
}
}