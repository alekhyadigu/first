class Single{
	int x;
	//static int p;
	void show()
	{
		System.out.println("main class");
		//System.out.println("x="+x);
	}
}	
	class S extends Single
	{
	void show()
	{
		System.out.println("show()");
		System.out.println("x="+x);
		super.show();
	}
	
public static void main (String ar[]){
S a1=new S();
a1.show();
}
}