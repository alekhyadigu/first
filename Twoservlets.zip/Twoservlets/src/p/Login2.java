package p;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Login2 extends HttpServlet {
	//private static final long serialVersionUID=1L;
	Connection conn=null;
	String url="jdbc:mysql://localhost:3306/";
	String dbName= "db1";
	String driver="com.mysql.jdbc.Driver";
	String userName="root";
	String password="root";

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		       
        try
        		{
        	
        		PrintWriter out= response.getWriter();
        		String s=request.getParameter("ecode");
        	    String s1=request.getParameter("ename");
        		String s2=request.getParameter("click");
        		if(s2.equals("update"))
        		{
        			Class.forName(driver);
                	conn=DriverManager.getConnection(url+dbName,userName,password);
                	PreparedStatement ps=conn.prepareStatement("update emp set ename=? where ecode=?");
                	ps.setString(1, s1);
                	ps.setString(2, s);


                	int x=ps.executeUpdate();
                	conn.close();
         
        		  out.println("updated");
        		}
        		else if(s2.equals("delete"))
        		{
        			Class.forName(driver);
                	conn=DriverManager.getConnection(url+dbName,userName,password);
                	PreparedStatement ps=conn.prepareStatement("delete from emp where ecode=?");
                	ps.setString(1, s);
                	


                	int x=ps.executeUpdate();
                	conn.close();
         
        			out.print("deleted");
        		}
        		}
        
        catch(Exception e) {}
	
}
}
	

